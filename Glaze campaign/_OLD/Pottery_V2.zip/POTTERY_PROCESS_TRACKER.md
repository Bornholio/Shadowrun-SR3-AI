# POTTERY Process Tracker

Updated: 2026-09-29

## Purpose

Keep the POTTERY repair/reorganization process durable across chats and context compression. This file records what has been established, what must not be changed casually, what needs investigation, and what work remains.

This is a process-control file, not campaign canon and not a replacement for the session carryover files.

## Current Goal

Prepare POTTERY for Session 26 so ChatGPT can provide useful lightweight narration without requiring the user to manually feed it information, while avoiding early context overload/compression.

Two compact carryover files should be sufficient to start Session 26 correctly before deeper retrieval is needed:

1. Session/world-state carryover for Session 26.
2. Main-character interpersonal carryover for Session 26.

These must retain all Session 25 developments still needed for Session 26. Material removed from always-loaded context must remain available in deeper history/RAG sources rather than being discarded.

## Established Facts

- The campaign has completed Session 25; Session 26 is next.
- Session 25 material must be advanced into Session 26 continuity.
- Too little carryover causes immediate continuity failure.
- Too much carryover causes early context compression and degraded play.
- ChatGPT must retrieve available campaign information itself when possible.
- The user should not have to identify source files/selectors for ChatGPT.
- If consequential information is genuinely absent or materially conflicting, ChatGPT should ask rather than invent it.
- Inconsequential narrative gaps may be filled conservatively when doing so does not alter established campaign facts.
- Rules.md is intended for first-prompt loading.
- SKILL_ACTIVATION_HEADER.md is currently stale/wrong because the available Skill set changed.
- TEAM_RESOURCES_RAG.md is primarily human-facing and does not need to be optimized at the expense of usability.

## Corpus Assessment So Far

### Preserve / use as structural reference

- HELPER_FILES_REFERENCE.md
- HF_SOURCE_01_100_SETTING.md
- HF_SOURCE_02_200_NPCS.md
- HF_SOURCE_03_300_GEAR.md
- HF_SOURCE_04_400_MATRIX.md
- HF_SOURCE_05_500_SEATTLE.md
- HF_SOURCE_06A_600_619_ADVENTURES.md
- HF_SOURCE_06B_620_629_ADVENTURES.md
- HF_SOURCE_06_600_ADVENTURES.md
- HF_SOURCE_07_700_CHARACTER_OPTIONS.md
- HF_SOURCE_08_800_RULES_TESTS_SPELLS.md

Reason: these were deliberately organized by the user and form the strongest existing retrieval system.

### Repair targets

- State_RAG.md
  - Contains two separate state systems.
  - Organization has become randomized/messy.
  - Needs reconciliation around Session 26 continuity, not cosmetic reformatting.

- History_0_RAG.md
- History_1_7_RAG.md
- History_8_14_RAG.md
- History_15_19_RAG.md
- History_20_24_RAG.md
  - User had already split/reorganized history before later RAG modification damaged that work.
  - Goal is to recover/preserve useful organization, not invent a new history ontology.

- INTERACTIONS_RAG.md
  - Large accumulated RAG artifact produced through prior ChatGPT restructuring.
  - Needs repair focused on retrieval and continuity, not another unconstrained rewrite.

### Transitional / crossroads material

- INTERACTIONS_25_V2.md
  - Exists because Session 25 interpersonal information must be carried forward while relevant information is also incorporated into the deeper interaction history/RAG.
  - Must contribute to the Session 26 interpersonal carryover.

- Session/world-state carryover source
  - A second crossroads file/system exists for general Session 25 -> Session 26 continuity.
  - Exact current source/file relationship must be verified from the corpus before modifying anything.

### Other sources

- CONTACTS_RAG.md
- GLAZE_SOURCE.md
- SINGER_SOURCE.md
  - Individually structured; do not assume they need redesign merely because they use a different scheme from HF.

- TEAM_RESOURCES_RAG.md
  - Primarily for user use.

- VEHICLE_TRACKING.md
  - Role and retrieval requirements still to be assessed.

- Rules.md
  - First-prompt control file. Keep separate from campaign narrative/history.

- SKILL_ACTIVATION_HEADER.md
  - Must be revisited after the restored Skills are reviewed.

## Narration / Retrieval Behavior Required

During play, use this order:

1. Use the always-loaded Session 26 carryover files.
2. Determine the current scene, people, location, and active unresolved threads.
3. Retrieve only deeper information relevant to those elements.
4. Narrate without preloading unrelated campaign history.
5. When the scene changes, retrieve newly relevant material.
6. Before asking the user for an established campaign fact, search available project sources.
7. Ask only when consequential information is actually absent or materially conflicting.
8. Do not invent consequential campaign facts to avoid asking.

## Skill Review Workstream

Status: NOT YET REVIEWED IN DETAIL.

The SR3 Skills are available again. They must be examined before SKILL_ACTIVATION_HEADER.md is repaired.

Current visible Skill set includes:

- sr3-concepts-tests-pools
- sr3-active-and-passive-skill-ratings
- sr3-special-abilities
- sr3-shamanic-mask-vs-masking
- sr3-quick-decking
- sr3-nanotech
- sr3-metamagic
- sr3-karma
- sr3-implant-detection
- sr3-house-rules
- sr3-genetech
- sr3-conjuring
- sr3-bioware
- sr3-astral
- sr3-action-economy
- sr3-damage-conditions
- sr3-matrix-rules
- sr3-spellcasting
- sr3-spells
- sr3-comm-rules
- sr3-cyberware
- sr3-matrix-ops
- sr3-social-tests
- sr3-perception-surprise
- sr3-example-hosts
- sr3-healing-stun
- sr3-armor-types
- sr3-firearms
- sr3-athletics

Review goals:

1. Determine which Skills are useful as on-demand rules references during narrative play.
2. Determine which Skills should never be preloaded or broadly activated because they add context/noise without helping the current scene.
3. Check overlap between Skills and HF rule/reference material.
4. Check whether any Skill instructions encourage ChatGPT to take over non-narrative GM functions the user intentionally removed.
5. Identify any missing rules coverage that currently forces unnecessary source retrieval or user correction.
6. Rebuild SKILL_ACTIVATION_HEADER.md only after this review.

## Process Rules

- Do not globally redesign POTTERY.
- Do not modify HF organization without a demonstrated retrieval problem.
- Do not perform unconstrained whole-corpus rewriting.
- Do not rely on conversation memory to track work; update this file as decisions are made.
- Do not discard information merely because it is removed from always-loaded context.
- Preserve originals while testing any replacement/repair.
- Prefer human review by exception rather than making the user manually classify or compare the corpus.
- Keep outputs concise enough that the repair process itself does not consume the working context.

## Work Queue

### Stage 1 - Understand before editing

- [x] Inspect POTTERY archive structure.
- [x] Identify HF as the strongest deliberate retrieval subsystem.
- [x] Establish that Session 26 is next and must retain relevant Session 25 continuity.
- [x] Establish two-file always-loaded continuity goal.
- [ ] Inspect restored SR3 Skills in enough detail to understand their activation behavior and overlap.
- [ ] Re-evaluate SKILL_ACTIVATION_HEADER.md against the current Skill set.
- [ ] Identify the exact current source(s) feeding the Session 26 world/state carryover.
- [ ] Trace how INTERACTIONS_25_V2 should feed both Session 26 interpersonal carryover and deeper interaction history.

### Stage 2 - Diagnose repair targets

- [ ] Diagnose State_RAG.md's two state systems and identify which information is current, historical, duplicated, or misplaced.
- [ ] Diagnose History files for damage introduced by prior RAG modification while preserving the user's existing split.
- [ ] Diagnose INTERACTIONS_RAG.md structure and determine the minimum repair required.
- [ ] Check the remaining non-HF sources only for concrete retrieval/continuity problems.

### Stage 3 - Design Session 26 carryover

- [ ] Define the minimum sufficient Session 26 world/state header from actual campaign material.
- [ ] Define the minimum sufficient Session 26 interpersonal carryover from actual campaign material.
- [ ] Verify that omitted details remain retrievable from deeper sources.
- [ ] Check that the two always-loaded files do not duplicate large amounts of the same information.

### Stage 4 - Repair deeper retrieval

- [ ] Repair only the sources demonstrated to cause retrieval problems.
- [ ] Preserve provenance to original material.
- [ ] Test retrieval against likely Session 26 narration needs.
- [ ] Keep HF intact unless testing finds a specific failure.

### Stage 5 - Finalize control files

- [ ] Update Rules.md only if actual observed behavior requires a control change.
- [ ] Rebuild SKILL_ACTIVATION_HEADER.md based on the reviewed Skill set.
- [ ] Record final Session 26 startup/loading procedure.

## Current Stop Point

No corpus repair has begun. The next investigation should be the restored Skill set and its relationship to SKILL_ACTIVATION_HEADER.md, followed by tracing the two Session 25 -> Session 26 carryover paths.
